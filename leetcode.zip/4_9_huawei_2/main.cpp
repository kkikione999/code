#include <iostream>
#include <vector>
using namespace std;



int main(){

  int N;
  cin>>N;
  char distination,source;
  cin>>source>>distination;




  return 0;
}